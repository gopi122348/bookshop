#!/bin/bash
cd /var/app/current
python manage.py migrate --noinput
